import random
#Verbs
work = ["work","works","working","worked"]
eat = ["eat","eats","eating","ate"]

#Topics
jobs = ["developer","cashier","engineer","soldier","officer"]
family = ["mother","father","mom","dad","brother","sister","son","daughter","family","uncle","aunt"]
food = ["banana","apple","orange","watermelon","peach","mango"]
vehicles = ["car","bus","train","plane"]
swearwords = ["bitch","fuck","fucking","shit","nigga","nigger"]

#Answers
work_ans = ["I worked too as ","Had also a job being a ","Fun fact i once worked as ","My job is being a "]
vehicles_ans = ["I like ","I love ","I dont like ","I hate ","I actually own a "]
eat_ans = ["My favourite food is ","I love ","You should really try "]
swear_ans = ["Hey dont say that :,<","Swearing is bad :<"]
food_ans = ["I love ","I hate ","I just ate ","I like ","I like "]
reaction_ans = ["Yeah right ;>","Crazy, isnt it :>","I knew you would say that!"]

#Smalltalk
greetings = ["hello","hi","wsp","sup","hey","yo"]
farewell = ["bye","cya","gtg","seeya"]

#Agreement
agrees = ["yes","yeah","agreed"]
unagrees = ["no","nah","nope","never","unagreed"]

#Reactions
positive_reaction = ["cool","nice","neat"]

#Uncategorised
curious = ["Tell me more :>","Interesting fact, continue","Thats actually crazy, tell me more!","Continue ^^"]
curious_about_your = ["Tell me more about your ","Cool fact, continue with your "]
doesnt_understand = ["Sorry I didnt understand anything :<","Could you repeat that?","What?","I dont understand."]
repeated = ["You just said the exact same","You already said that","You repeated yourself"]

#Mixed



last_inp = None
didnt_understand = False
content = []
def main():
	global last_inp, didnt_understand, content
	while True:


		ans = {
			("family","job") : ["My "+random.choice(family)+" works as "+random.choice(jobs)],
			("family","food") : ["My "+random.choice(family)+" loves "+random.choice(food)],
			("family","vehicles") : ["My "+random.choice(family)+" owns a "+random.choice(vehicles)],
			("family","swear") : ["Interesting fact but I dont like swearing :<"],
			("job","food") : ["Interesting","Cool fact"],
			("job","vehicles"): ["My job just brought me a "+random.choice(vehicles)],
			("job","swear"): ["I worked too as "+ random.choice(jobs)+" also please stop swearing"],
			("food","vehicles"): ["Interesting","Cool fact"],
			("food","swear") : ["Swearing aint great :<"]
		}

		inp = input(">").lower().split()
		content = []
		if last_inp != inp:
			#Topics
			if any(word in inp for word  in family):
				content.append("family")
			if any(word in inp for word in jobs):
				content.append("job")
			if any(word in inp for word in food):
				content.append("food")
			if any(word in inp for word in vehicles):
				vehicle_wrd = next(word for word in inp if word in vehicles)
				content.append("vehicles")
			if any(word in inp for word in swearwords):
				content.append("swear")
			if len(content) < 2:
				#Smalltalk
				if any(word in inp for word  in family):
					print(random.choice(curious_about_your)+"family")
				elif any(word in inp for word in jobs):
					print(random.choice(work_ans)+jobs)
				elif any(word in inp for word in food):
					print(random.choice(food_ans)+random.choice(food))
				elif any(word in inp for word in vehicles):
					vehicle_wrd = next(word for word in inp if word in vehicles)
					print(random.choice(vehicles_ans)+vehicle_wrd)
				elif any(word in inp for word in swearwords):
					print(random.choice(swear_ans))
				elif any(word in inp for word in greetings):
					print(random.choice(greetings))
				elif any(word in inp for word in farewell):
					print(random.choice(farewell))
				#Verbs
				elif any (word in inp for word in work):
					print(random.choice(work_ans)+random.choice(jobs))
				elif any(word in inp for word in eat):
					print(random.choice(eat_ans)+random.choice(food))
				#Reactions
				elif any (word in inp for word in positive_reaction):
					print(random.choice(reaction_ans))
				#Uncategorised
				else:
					didnt_understand = True
					print(random.choice(doesnt_understand))
			else:
				if len(content) > 1:
					key = tuple(sorted(content))
					print(random.choice(ans[key]))
		else:
			print(random.choice(repeated))
		if didnt_understand == False:
			last_inp = inp
		didnt_understand = False

main()