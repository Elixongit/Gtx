import random, os,string

txt = None
history = []
tmphistory = []
last_inp = None
didnt_understand = False
content = []
repeat_count = 0


#Words
remove = ["remove","delete","wipe","kill","destroy","terminate"]
line = ["line","lines","text","texts","message","messages"]

#Verbs
work = ["work","works","working","worked"]
love = ["love","loves","loved","loving"]
eat = ["eat","eats","eating","ate"]

#Topics
jobs = ["developer","cashier","engineer","soldier","officer"]
family = ["mother","father","mom","dad","brother","sister","son","daughter","family","uncle","aunt"]
food = ["banana","apple","orange","watermelon","peach","mango"]
vehicles = ["car","bus","train","plane"]
swearwords = ["bitch","fuck","fucking","shit","nigga","nigger"]
tabuwords = ["anal","oral","sex","tit","tits"]
genders = ["male","female"]
#Answers
work_ans = ["I worked too as ","Had also a job being a ","Fun fact i once worked as ","My job is being a "]
vehicles_ans = ["I like ","I love ","I dont like ","I hate ","I actually own a "]
eat_ans = ["My favourite food is ","I love ","You should really try "]
swear_ans = ["Hey dont say that :,<","Swearing is bad :<"]
food_ans = ["I love ","I hate ","I just ate ","I like ","I like "]
reaction_ans = ["Yeah right ;>","Crazy, isnt it :>","I knew you would say that!"]

#Smalltalk
greetings = ["hello","hi","wsp","sup","hey","yo"]
farewell = ["bye","cya","gtg","seeya"]

#Agreement
agrees = ["yes","yeah","agreed"]
unagrees = ["no","nah","nope","never","unagreed"]

#Reactions
positive_reaction = ["cool","nice","neat"]
opinion = ["I like ","I love ","I dont like ","I hate "]
#Uncategorised
curious = ["Tell me more :>","Interesting fact, continue","Thats actually crazy, tell me more!","Continue ^^"]
curious_about_your = ["Tell me more about your ","Cool fact, continue with your "]
doesnt_understand = ["Sorry I didnt understand anything :<","Could you repeat that?","What?","I dont understand.","No clue what you wanted to tell by that"]
doesnt_understand2 = ["Yeah i still don't understand anything sorry :/","I still dont get it..","Could we talk about something different I still dont get it","You dont need to repeat I dont get it"]
repeated = ["You just said the exact same","You already said that","You repeated yourself"]
repeated2 = ["You said that for the 3rd time already","Alright i get it you can stop now"]

were_sorry = ["Sorry cant help with that :<","Is this a joke or are you for real? Eather way i cant answer to that","Unfunny"]



def main():
	global last_inp, didnt_understand, content, history, tmphistory, repeat_count
	while True:
		repeated3 = [str(repeat_count+1)+"th time you said that you can stop..","You already repeated that "+str(repeat_count+1)+" times stop already..",".."]


		ans = {
			("family","job") : ["My "+random.choice(family)+" works as "+random.choice(jobs)],
			("family","food") : ["My "+random.choice(family)+" loves "+random.choice(food)],
			("family","vehicles") : ["My "+random.choice(family)+" owns a "+random.choice(vehicles)],
			("family","swear") : ["Interesting fact but I dont like swearing :<"],
			("job","food") : ["Interesting","Cool fact"],
			("job","vehicles"): ["My job just brought me a "+random.choice(vehicles)],
			("job","swear"): ["I worked too as "+ random.choice(jobs)+" also please stop swearing"],
			("food","vehicles"): ["Interesting","Cool fact"],
			("food","swear") : ["Swearing aint great :<"]
		}

		inp_raw = input(">").lower()
		inp = inp_raw.translate(str.maketrans('', '', string.punctuation)).split()
		content = []
		if last_inp != inp:
			#Topics
			if any(word in inp for word  in family):
				content.append("family")
			if any(word in inp for word in jobs):
				content.append("job")
			if any(word in inp for word in food):
				content.append("food")
			if any(word in inp for word in vehicles):
				vehicle_wrd = next(word for word in inp if word in vehicles)
				content.append("vehicles")
			if any(word in inp for word in swearwords):
				content.append("swear")
			history.append(">"+inp_raw)
			tmphistory.append(">"+inp_raw)
			if len(content) < 2:
				#Commands
				if any(word in inp for word in remove):
					if any(word in inp for word in line):
						tmphistory = tmphistory[:-4]
						os.system("cls" if os.name == "nt" else "clear")
						for ln in tmphistory:
							print(ln)
				#Smalltalk
				elif any(word in inp for word  in family):
					family_wrd = next(word for word in inp if word in family)
					if any(word in inp for word in love):
						txt = random.choice(opinion)+family_wrd+" too :>"
					else:
						txt = random.choice(curious_about_your)+"family"
				elif any(word in inp for word in jobs):
					txt = random.choice(work_ans)+random.choice(jobs)
				elif any(word in inp for word in food):
					txt = random.choice(food_ans)+random.choice(food)
				elif any(word in inp for word in vehicles):
					vehicle_wrd = next(word for word in inp if word in vehicles)
					txt = random.choice(vehicles_ans)+vehicle_wrd
				elif any(word in inp for word in swearwords):
					txt = random.choice(swear_ans)
				elif any(word in inp for word in greetings):
					txt = random.choice(greetings)
				elif any(word in inp for word in farewell):
					txt = random.choice(farewell)
				elif any(word in inp for word in tabuwords):
					txt = random.choice(were_sorry)
				#Verbs
				elif any (word in inp for word in work):
					txt = random.choice(work_ans)+random.choice(jobs)
				elif any(word in inp for word in eat):
					txt = random.choice(eat_ans)+random.choice(food)
				#Reactions
				elif any (word in inp for word in positive_reaction):
					txt = random.choice(reaction_ans)
				#Uncategorised
				else:
					didnt_understand = True
					if repeat_count == 0:
						txt = random.choice(doesnt_understand)
					else:
						txt = random.choice(doesnt_understand2)
					last_inp = None
					repeat_count += 1
			else:
				if len(content) > 1:
					key = tuple(sorted(content))
					txt = random.choice(ans[key])
		else:
			if repeat_count == 1:
				txt = random.choice(repeated)
			elif repeat_count == 2:
				txt = random.choice(repeated2)
			elif repeat_count > 2:
				txt = random.choice(repeated3)
		print(txt)
		print()
		history.append(txt)
		tmphistory.append(txt)
		if didnt_understand == False:
			last_inp = inp
			repeat_count += 1
		
		didnt_understand = False

main()